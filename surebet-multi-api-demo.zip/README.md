# Surebet Multi-API Tool (Demo)

Live comparison between 1xBet and BajiLive cricket odds.

Run locally:
```
npm install
npm run dev
```
